// import { pdfjs } from 'react-pdf';
// import worker from 'pdfjs-dist/build/pdf.worker.entry';

// pdfjs.GlobalWorkerOptions.workerSrc = worker;

// // workerLoader.js
// export const loadWorker = () => {
//     if (typeof window !== 'undefined') {
//         const workerSrc = `/path/to/pdf.worker.min.js`; // Update the path as needed
//         if (pdfjs.GlobalWorkerOptions.workerSrc !== workerSrc) {
//             pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;
//         }
//     }
// };
